# SWTK
Experimental MLops toolkit for Cyber work

This toolkit is designed to be run from the CLI making it the easiest and the quickest to use. This code utilizes a Trie model that my friend Julien made for this project in RUST!.

This software currently only supports unsupervised log anomaly detection.
It will automatically sort your input based on weirdness
## Requirements
Python3
Sudo permissions if on Linux/Mac (For compiling through cargo)
cargo
Internet connection for the first run setup
Basic bash tools like curl and mv and stuff

## How to install?

just download SWTK.py and run it with python

## How to use?

SWTK -i sample.txt

Try the -h command for more stuff
